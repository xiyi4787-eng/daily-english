# 每日英语 3.0

安卓应用。30 天课程内置在安装包中，每天 20 句，共 600 句中英对照。第 1 天保留旧版 20 句。

## 使用

- 首次打开从第 1 天开始，之后按手机本地日期切换，第 30 天以后停在最后一课。
- 用「上一天」「下一天」复习或预习，用「今日课程」回到当天。每课会单独记住上次看到的句子。
- 学到最后一句，点「完成本课」保存完成状态。
- 课程文字可离线查看。离线朗读使用手机已安装的英语语音，可在手机的文字转语音设置中下载。
- 覆盖升级成功后，应用将旧版留存的句子位置迁移到第 1 天。

## 编译和安装

GitHub Actions 中的 Build Daily English APK 可以手动运行。向 main 推送也会生成测试包，供模拟器或手机验证。测试包显示为「每日英语测试版」，可以与原来的《每日英语》同时安装，学习进度各自保存。

正式打包前，先确定要使用的长期签名。若要覆盖手机上的旧版本，先核对旧版签名证书与准备用来编译的证书。请保管好密钥及密码，勿提交到仓库。

在 GitHub 仓库的 Actions Secrets 中配置以下四项。在 Actions 中手动运行工作流，并勾选「使用已配置的固定签名生成正式安装包」。编译完成后下载 Daily-English-3.0-Signed，解压后得到 app-release.apk。

| 名称 | 内容 |
|---|---|
| `DAILY_ENGLISH_KEYSTORE_BASE64` | 签名密钥库文件的 Base64 内容 |
| `DAILY_ENGLISH_KEYSTORE_PASSWORD` | 密钥库密码 |
| `DAILY_ENGLISH_KEY_ALIAS` | 签名密钥名称 |
| `DAILY_ENGLISH_KEY_PASSWORD` | 签名密钥密码 |

本地可用 Java 17、Gradle 8.9、Android SDK 35 和 Android Build Tools 35.0.0 编译。运行 `gradle assembleDebug` 生成测试 APK。
