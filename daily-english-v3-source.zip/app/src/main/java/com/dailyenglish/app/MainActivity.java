package com.dailyenglish.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private static final int DAYS = 30;
    private static final int SENTENCES_PER_DAY = 20;
    private static final long MILLIS_PER_DAY = 86_400_000L;
    private static final int INK = Color.rgb(22, 48, 89);
    private static final int SECONDARY = Color.rgb(65, 79, 99);

    private final String[] topics = new String[DAYS];
    private final String[][] english = new String[DAYS][SENTENCES_PER_DAY];
    private final String[][] chinese = new String[DAYS][SENTENCES_PER_DAY];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refreshDate = new Runnable() {
        @Override public void run() {
            int date = localDate();
            boolean newDate = date != lastDate;
            lastDate = date;
            int currentDay = Math.min(DAYS - 1, Math.max(0, date - startDate));
            if (newDate) {
                today = currentDay;
                moveToDay(today);
            }
            handler.postDelayed(this, 15_000L);
        }
    };

    private SharedPreferences prefs;
    private int startDate, lastDate, today, day, index;
    private TextView topic, progress, sentence, translation, speechStatus;
    private Button previousDay, nextDay, previous, next, speak;
    private TextToSpeech tts;
    private boolean speechReady, courseLoaded;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            loadCourse();
        } catch (IOException | JSONException error) {
            setContentView(label("课程文件无法读取，请重新安装完整的《每日英语》安装包。", 18, INK));
            return;
        }

        prefs = getSharedPreferences("daily_english", MODE_PRIVATE);
        lastDate = localDate();
        startDate = prefs.getInt("course_start", lastDate);
        if (!prefs.contains("course_start")) {
            prefs.edit().putInt("course_start", startDate)
                    .putInt("position_0", prefs.getInt("index", 0)).apply();
        }
        today = Math.min(DAYS - 1, Math.max(0, lastDate - startDate));
        buildView();
        int initialDay = today;
        if (savedInstanceState != null && savedInstanceState.getInt("view_date") == lastDate) {
            initialDay = Math.min(DAYS - 1, Math.max(0, savedInstanceState.getInt("view_day", today)));
        }
        moveToDay(initialDay);
        courseLoaded = true;
        tts = new TextToSpeech(this, status -> handler.post(() -> prepareVoice(status)));
    }

    private void loadCourse() throws IOException, JSONException {
        try (InputStream input = getAssets().open("lessons.json");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            JSONArray lessons = new JSONArray(new String(output.toByteArray(), StandardCharsets.UTF_8));
            if (lessons.length() != DAYS) {
                throw new JSONException("Expected 30 lessons");
            }
            for (int lesson = 0; lesson < DAYS; lesson++) {
                topics[lesson] = lessons.getJSONObject(lesson).getString("title");
                JSONArray rows = lessons.getJSONObject(lesson).getJSONArray("sentences");
                if (rows.length() != SENTENCES_PER_DAY) {
                    throw new JSONException("Expected 20 sentences per lesson");
                }
                for (int row = 0; row < SENTENCES_PER_DAY; row++) {
                    JSONArray pair = rows.getJSONArray(row);
                    english[lesson][row] = pair.getString(0);
                    chinese[lesson][row] = pair.getString(1);
                }
            }
        }
    }

    private static int localDate() {
        Calendar local = Calendar.getInstance();
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.clear();
        utc.set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH));
        return (int) (utc.getTimeInMillis() / MILLIS_PER_DAY);
    }

    private void buildView() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(247, 249, 253));
        scroll.addView(root);

        TextView title = label("每日英语口语", 27, INK);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        topic = label("", 17, SECONDARY);
        topic.setPadding(0, dp(8), 0, dp(12));
        root.addView(topic);

        previousDay = button("上一天");
        Button current = button("今日课程");
        nextDay = button("下一天");
        addButtons(root, previousDay, current, nextDay);
        previousDay.setOnClickListener(view -> moveToDay(day - 1));
        current.setOnClickListener(view -> moveToDay(today));
        nextDay.setOnClickListener(view -> moveToDay(day + 1));

        progress = label("", 16, INK);
        progress.setPadding(0, dp(18), 0, dp(8));
        root.addView(progress);
        sentence = label("", 27, Color.BLACK);
        sentence.setPadding(dp(6), dp(18), dp(6), dp(12));
        root.addView(sentence);
        translation = label("", 21, SECONDARY);
        translation.setPadding(dp(6), 0, dp(6), dp(20));
        root.addView(translation);

        speak = button("朗读英语");
        speak.setEnabled(false);
        speak.setOnClickListener(view -> {
            if (speechReady && tts.speak(english[day][index], TextToSpeech.QUEUE_FLUSH, null, "sentence")
                    == TextToSpeech.ERROR) {
                speechStatus.setText("朗读启动失败，请检查手机的英语语音设置。");
            }
        });
        root.addView(speak);

        previous = button("上一句");
        next = button("下一句");
        addButtons(root, previous, next);
        previous.setOnClickListener(view -> moveToSentence(index - 1));
        next.setOnClickListener(view -> {
            if (index == SENTENCES_PER_DAY - 1) {
                prefs.edit().putBoolean("completed_" + day, true).apply();
                render();
            } else {
                moveToSentence(index + 1);
            }
        });

        speechStatus = label("正在准备离线英语语音…", 14, SECONDARY);
        speechStatus.setPadding(0, dp(14), 0, 0);
        root.addView(speechStatus);
        setContentView(scroll);
    }

    private void prepareVoice(int status) {
        if (tts == null || isDestroyed()) {
            return;
        }
        if (status == TextToSpeech.SUCCESS && tts.getVoices() != null) {
            Voice best = null;
            for (Voice voice : tts.getVoices()) {
                if (voice.isNetworkConnectionRequired() || !Locale.ENGLISH.getLanguage().equals(voice.getLocale().getLanguage())
                        || (voice.getFeatures() != null && voice.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED))) {
                    continue;
                }
                if (best == null || (Locale.US.getCountry().equals(voice.getLocale().getCountry())
                        && !Locale.US.getCountry().equals(best.getLocale().getCountry()))) {
                    best = voice;
                }
            }
            speechReady = best != null && tts.setVoice(best) == TextToSpeech.SUCCESS;
        }
        speak.setEnabled(speechReady);
        speechStatus.setText(speechReady ? "可离线朗读" : "朗读需要离线英语语音，请在手机的文字转语音设置中安装，完成后重新打开应用。");
    }

    private void moveToDay(int targetDay) {
        if (targetDay < 0 || targetDay >= DAYS) {
            return;
        }
        stopSpeech();
        day = targetDay;
        index = Math.min(SENTENCES_PER_DAY - 1, Math.max(0, prefs.getInt("position_" + day, 0)));
        render();
        clearSpeechError();
    }

    private void moveToSentence(int targetIndex) {
        if (targetIndex < 0 || targetIndex >= SENTENCES_PER_DAY) {
            return;
        }
        stopSpeech();
        index = targetIndex;
        prefs.edit().putInt("position_" + day, index).apply();
        render();
        clearSpeechError();
    }

    private void clearSpeechError() {
        if (speechReady) {
            speechStatus.setText("可离线朗读");
        }
    }

    private void stopSpeech() {
        if (speechReady && tts != null) {
            tts.stop();
        }
    }

    private void render() {
        boolean completed = prefs.getBoolean("completed_" + day, false);
        String mode = day == today ? "今日课程" : day < today ? "历史复习" : "课程预习";
        topic.setText("第 " + (day + 1) + " 天 · " + topics[day]);
        progress.setText(mode + " · 第 " + (index + 1) + " / " + SENTENCES_PER_DAY + " 句"
                + (completed ? " · 已完成" : ""));
        sentence.setText(english[day][index]);
        translation.setText(chinese[day][index]);
        previousDay.setEnabled(day > 0);
        nextDay.setEnabled(day < DAYS - 1);
        previous.setEnabled(index > 0);
        boolean lastSentence = index == SENTENCES_PER_DAY - 1;
        next.setText(lastSentence ? "完成本课" : "下一句");
        next.setEnabled(!lastSentence || !completed);
    }

    private TextView label(String value, int size, int color) {
        TextView text = new TextView(this);
        text.setGravity(Gravity.CENTER);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        return text;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setMinHeight(dp(48));
        return button;
    }

    private void addButtons(LinearLayout root, Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        for (Button button : buttons) {
            row.addView(button, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        }
        root.addView(row);
    }

    private int dp(int size) {
        return Math.round(size * getResources().getDisplayMetrics().density);
    }

    @Override protected void onResume() {
        super.onResume();
        if (courseLoaded) {
            refreshDate.run();
        }
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refreshDate);
        stopSpeech();
        super.onPause();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putInt("view_day", day);
        state.putInt("view_date", lastDate);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (tts != null) {
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }
}
